const mongoose = require('mongoose');

const tableSchema = new mongoose.Schema({
  number: {
    type: Number,
    required: [true, 'Número da mesa é obrigatório'],
    unique: true,
    min: [1, 'Número da mesa deve ser maior que 0']
  },
  capacity: {
    type: Number,
    required: [true, 'Capacidade da mesa é obrigatória'],
    min: [1, 'Capacidade deve ser maior que 0'],
    max: [20, 'Capacidade não pode ser maior que 20']
  },
  status: {
    type: String,
    enum: ['available', 'occupied', 'reserved', 'maintenance'],
    default: 'available'
  },
  section: {
    type: String,
    required: [true, 'Seção da mesa é obrigatória'],
    trim: true
  },
  currentOrder: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Order',
    default: null
  },
  qrCode: {
    type: String,
    required: true
  },
  coordinates: {
    x: { type: Number, default: 0 },
    y: { type: Number, default: 0 }
  },
  notes: {
    type: String,
    maxlength: [500, 'Observações não podem ter mais de 500 caracteres']
  }
}, {
  timestamps: true
});

// Generate QR code URL before saving
tableSchema.pre('save', function(next) {
  if (!this.qrCode) {
    this.qrCode = `${process.env.FRONTEND_URL || 'http://localhost:5173'}/cardapio?table=${this.number}`;
  }
  next();
});

module.exports = mongoose.model('Table', tableSchema);