const mongoose = require('mongoose');

const inventoryItemSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Nome do item é obrigatório'],
    trim: true,
    maxlength: [100, 'Nome não pode ter mais de 100 caracteres']
  },
  category: {
    type: String,
    required: [true, 'Categoria é obrigatória'],
    trim: true
  },
  unit: {
    type: String,
    required: [true, 'Unidade é obrigatória'],
    trim: true
  },
  currentStock: {
    type: Number,
    required: [true, 'Estoque atual é obrigatório'],
    min: [0, 'Estoque não pode ser negativo']
  },
  minimumStock: {
    type: Number,
    required: [true, 'Estoque mínimo é obrigatório'],
    min: [0, 'Estoque mínimo não pode ser negativo']
  },
  maximumStock: {
    type: Number,
    required: [true, 'Estoque máximo é obrigatório'],
    min: [1, 'Estoque máximo deve ser maior que 0']
  },
  unitCost: {
    type: Number,
    required: [true, 'Custo unitário é obrigatório'],
    min: [0, 'Custo não pode ser negativo']
  },
  supplier: {
    type: String,
    trim: true
  },
  expirationDate: {
    type: Date,
    default: null
  },
  barcode: {
    type: String,
    trim: true
  },
  location: {
    type: String,
    trim: true
  },
  notes: {
    type: String,
    maxlength: [500, 'Observações não podem ter mais de 500 caracteres']
  }
}, {
  timestamps: true
});

// Validate that maximum stock is greater than minimum stock
inventoryItemSchema.pre('save', function(next) {
  if (this.maximumStock <= this.minimumStock) {
    next(new Error('Estoque máximo deve ser maior que o estoque mínimo'));
  }
  next();
});

module.exports = mongoose.model('InventoryItem', inventoryItemSchema);