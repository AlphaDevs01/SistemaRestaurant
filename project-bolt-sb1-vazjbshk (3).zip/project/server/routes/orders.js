const express = require('express');
const { body, validationResult } = require('express-validator');
const Order = require('../models/Order');
const Table = require('../models/Table');
const MenuItem = require('../models/MenuItem');
const { auth, authorize } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/orders
// @desc    Get all orders
// @access  Private
router.get('/', auth, async (req, res) => {
  try {
    const { status, type, tableId, date } = req.query;
    let query = {};

    // Filter by status
    if (status) {
      query.status = status;
    }

    // Filter by type
    if (type) {
      query.type = type;
    }

    // Filter by table
    if (tableId) {
      query.tableId = tableId;
    }

    // Filter by date
    if (date) {
      const startDate = new Date(date);
      const endDate = new Date(date);
      endDate.setDate(endDate.getDate() + 1);
      query.createdAt = { $gte: startDate, $lt: endDate };
    }

    const orders = await Order.find(query)
      .populate('tableId', 'number section')
      .populate('customerId', 'name phone')
      .populate('waiterId', 'name')
      .populate('items.menuItem')
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      data: orders
    });
  } catch (error) {
    console.error('Get orders error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   GET /api/orders/:id
// @desc    Get order by ID
// @access  Private
router.get('/:id', auth, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id)
      .populate('tableId', 'number section')
      .populate('customerId', 'name phone email')
      .populate('waiterId', 'name')
      .populate('items.menuItem');

    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Pedido não encontrado'
      });
    }

    res.json({
      success: true,
      data: order
    });
  } catch (error) {
    console.error('Get order error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   POST /api/orders
// @desc    Create new order
// @access  Public (for digital menu) / Private (for internal orders)
router.post('/', [
  body('items').isArray({ min: 1 }).withMessage('Pelo menos um item é obrigatório'),
  body('items.*.menuItem').isMongoId().withMessage('ID do item do menu inválido'),
  body('items.*.quantity').isInt({ min: 1 }).withMessage('Quantidade deve ser um número positivo'),
  body('type').isIn(['dine-in', 'takeaway', 'delivery']).withMessage('Tipo de pedido inválido'),
  body('tableId').optional().isMongoId().withMessage('ID da mesa inválido')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: errors.array()
      });
    }

    const { items, type, tableId, customerId, notes, deliveryAddress } = req.body;

    // Validate menu items and calculate prices
    const orderItems = [];
    let subtotal = 0;

    for (const item of items) {
      const menuItem = await MenuItem.findById(item.menuItem);
      if (!menuItem) {
        return res.status(400).json({
          success: false,
          message: `Item do menu não encontrado: ${item.menuItem}`
        });
      }

      if (!menuItem.isAvailable) {
        return res.status(400).json({
          success: false,
          message: `Item não disponível: ${menuItem.name}`
        });
      }

      const orderItem = {
        menuItem: menuItem._id,
        quantity: item.quantity,
        price: menuItem.price,
        notes: item.notes || '',
        modifications: item.modifications || []
      };

      orderItems.push(orderItem);
      subtotal += menuItem.price * item.quantity;
    }

    // Validate table for dine-in orders
    if (type === 'dine-in' && tableId) {
      const table = await Table.findById(tableId);
      if (!table) {
        return res.status(400).json({
          success: false,
          message: 'Mesa não encontrada'
        });
      }
    }

    // Create order
    const order = new Order({
      items: orderItems,
      type,
      tableId: type === 'dine-in' ? tableId : undefined,
      customerId,
      waiterId: req.user ? req.user._id : undefined,
      subtotal,
      notes,
      deliveryAddress: type === 'delivery' ? deliveryAddress : undefined,
      deliveryFee: type === 'delivery' ? 5.00 : 0 // Fixed delivery fee
    });

    await order.save();

    // Update table status if dine-in
    if (type === 'dine-in' && tableId) {
      await Table.findByIdAndUpdate(tableId, {
        status: 'occupied',
        currentOrder: order._id
      });
    }

    // Populate the order for response
    await order.populate('items.menuItem');
    await order.populate('tableId', 'number section');

    // Emit real-time update to kitchen
    req.app.get('io').to('kitchen').emit('new-order', order);

    res.status(201).json({
      success: true,
      message: 'Pedido criado com sucesso',
      data: order
    });
  } catch (error) {
    console.error('Create order error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   PUT /api/orders/:id/status
// @desc    Update order status
// @access  Private
router.put('/:id/status', auth, [
  body('status').isIn(['pending', 'preparing', 'ready', 'served', 'paid', 'cancelled']).withMessage('Status inválido')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: errors.array()
      });
    }

    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Pedido não encontrado'
      });
    }

    const { status } = req.body;
    order.status = status;
    await order.save();

    // Update table status if order is paid or cancelled
    if ((status === 'paid' || status === 'cancelled') && order.tableId) {
      await Table.findByIdAndUpdate(order.tableId, {
        status: 'available',
        currentOrder: null
      });
    }

    // Emit real-time updates
    req.app.get('io').emit('order-status-updated', {
      orderId: order._id,
      status,
      tableId: order.tableId
    });

    res.json({
      success: true,
      message: 'Status do pedido atualizado com sucesso',
      data: order
    });
  } catch (error) {
    console.error('Update order status error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   PUT /api/orders/:id/items/:itemId/status
// @desc    Update order item status
// @access  Private
router.put('/:id/items/:itemId/status', auth, [
  body('status').isIn(['pending', 'preparing', 'ready', 'served']).withMessage('Status inválido')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: errors.array()
      });
    }

    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Pedido não encontrado'
      });
    }

    const item = order.items.id(req.params.itemId);
    if (!item) {
      return res.status(404).json({
        success: false,
        message: 'Item não encontrado'
      });
    }

    const { status } = req.body;
    item.status = status;
    await order.save();

    // Check if all items are ready to update order status
    const allItemsReady = order.items.every(item => item.status === 'ready');
    if (allItemsReady && order.status === 'preparing') {
      order.status = 'ready';
      await order.save();
    }

    // Emit real-time update
    req.app.get('io').emit('order-item-status-updated', {
      orderId: order._id,
      itemId: item._id,
      status
    });

    res.json({
      success: true,
      message: 'Status do item atualizado com sucesso',
      data: order
    });
  } catch (error) {
    console.error('Update order item status error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   DELETE /api/orders/:id
// @desc    Cancel order
// @access  Private
router.delete('/:id', auth, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Pedido não encontrado'
      });
    }

    // Only allow cancellation of pending or preparing orders
    if (!['pending', 'preparing'].includes(order.status)) {
      return res.status(400).json({
        success: false,
        message: 'Não é possível cancelar este pedido'
      });
    }

    order.status = 'cancelled';
    await order.save();

    // Update table status if applicable
    if (order.tableId) {
      await Table.findByIdAndUpdate(order.tableId, {
        status: 'available',
        currentOrder: null
      });
    }

    // Emit real-time update
    req.app.get('io').emit('order-cancelled', {
      orderId: order._id,
      tableId: order.tableId
    });

    res.json({
      success: true,
      message: 'Pedido cancelado com sucesso',
      data: order
    });
  } catch (error) {
    console.error('Cancel order error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

module.exports = router;