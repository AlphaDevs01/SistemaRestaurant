const express = require('express');
const Order = require('../models/Order');
const { auth } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/kitchen/orders
// @desc    Get kitchen orders (orders that need preparation)
// @access  Private
router.get('/orders', auth, async (req, res) => {
  try {
    const { station } = req.query;

    // Get orders that are pending or preparing
    const orders = await Order.find({
      status: { $in: ['pending', 'preparing'] },
      'items.status': { $in: ['pending', 'preparing'] }
    })
      .populate('tableId', 'number section')
      .populate('items.menuItem')
      .sort({ createdAt: 1 });

    // Transform orders for kitchen display
    const kitchenOrders = orders.map(order => {
      // Filter items that need kitchen preparation (exclude beverages)
      const kitchenItems = order.items.filter(item => 
        item.menuItem.category !== 'Bebidas' && 
        ['pending', 'preparing'].includes(item.status)
      );

      if (kitchenItems.length === 0) return null;

      // Determine priority based on order age
      const orderAge = Date.now() - order.createdAt.getTime();
      let priority = 'normal';
      if (orderAge > 30 * 60 * 1000) priority = 'urgent'; // 30 minutes
      else if (orderAge > 20 * 60 * 1000) priority = 'high'; // 20 minutes

      return {
        id: order._id,
        orderNumber: order.orderNumber,
        tableNumber: order.tableId?.number,
        items: kitchenItems.map(item => ({
          id: item._id,
          menuItem: item.menuItem,
          quantity: item.quantity,
          modifications: item.modifications,
          notes: item.notes,
          status: item.status,
          station: getStationForCategory(item.menuItem.category)
        })),
        priority,
        estimatedTime: Math.max(...kitchenItems.map(item => item.menuItem.preparationTime)),
        notes: order.notes,
        createdAt: order.createdAt
      };
    }).filter(Boolean);

    // Filter by station if specified
    let filteredOrders = kitchenOrders;
    if (station && station !== 'all') {
      filteredOrders = kitchenOrders.map(order => ({
        ...order,
        items: order.items.filter(item => item.station === station)
      })).filter(order => order.items.length > 0);
    }

    res.json({
      success: true,
      data: filteredOrders
    });
  } catch (error) {
    console.error('Get kitchen orders error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   PUT /api/kitchen/orders/:orderId/items/:itemId/status
// @desc    Update kitchen order item status
// @access  Private
router.put('/orders/:orderId/items/:itemId/status', auth, async (req, res) => {
  try {
    const { status } = req.body;
    
    if (!['pending', 'preparing', 'ready'].includes(status)) {
      return res.status(400).json({
        success: false,
        message: 'Status inválido'
      });
    }

    const order = await Order.findById(req.params.orderId);
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Pedido não encontrado'
      });
    }

    const item = order.items.id(req.params.itemId);
    if (!item) {
      return res.status(404).json({
        success: false,
        message: 'Item não encontrado'
      });
    }

    item.status = status;

    // Update order status based on item statuses
    if (status === 'preparing' && order.status === 'pending') {
      order.status = 'preparing';
    } else if (status === 'ready') {
      // Check if all items are ready
      const allItemsReady = order.items.every(item => 
        item.status === 'ready' || item.menuItem.category === 'Bebidas'
      );
      
      if (allItemsReady) {
        order.status = 'ready';
      }
    }

    await order.save();

    // Emit real-time updates
    req.app.get('io').to('kitchen').emit('kitchen-item-updated', {
      orderId: order._id,
      itemId: item._id,
      status
    });

    req.app.get('io').to('waiters').emit('order-status-updated', {
      orderId: order._id,
      status: order.status
    });

    res.json({
      success: true,
      message: 'Status atualizado com sucesso',
      data: { orderId: order._id, itemId: item._id, status }
    });
  } catch (error) {
    console.error('Update kitchen item status error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   GET /api/kitchen/stats
// @desc    Get kitchen statistics
// @access  Private
router.get('/stats', auth, async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const stats = await Order.aggregate([
      {
        $match: {
          createdAt: { $gte: today },
          status: { $ne: 'cancelled' }
        }
      },
      {
        $group: {
          _id: null,
          totalOrders: { $sum: 1 },
          pendingOrders: {
            $sum: { $cond: [{ $eq: ['$status', 'pending'] }, 1, 0] }
          },
          preparingOrders: {
            $sum: { $cond: [{ $eq: ['$status', 'preparing'] }, 1, 0] }
          },
          readyOrders: {
            $sum: { $cond: [{ $eq: ['$status', 'ready'] }, 1, 0] }
          },
          completedOrders: {
            $sum: { $cond: [{ $in: ['$status', ['served', 'paid']] }, 1, 0] }
          }
        }
      }
    ]);

    const result = stats[0] || {
      totalOrders: 0,
      pendingOrders: 0,
      preparingOrders: 0,
      readyOrders: 0,
      completedOrders: 0
    };

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    console.error('Get kitchen stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// Helper function to determine station based on category
function getStationForCategory(category) {
  switch (category) {
    case 'Hambúrgueres':
    case 'Carnes':
      return 'grill';
    case 'Pizzas':
    case 'Fritos':
      return 'fryer';
    case 'Saladas':
      return 'salad';
    case 'Sobremesas':
      return 'desserts';
    default:
      return 'grill';
  }
}

module.exports = router;