const express = require('express');
const Order = require('../models/Order');
const MenuItem = require('../models/MenuItem');
const { auth, authorize } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/reports/sales
// @desc    Get sales report
// @access  Private (Admin/Manager only)
router.get('/sales', [auth, authorize('admin', 'manager')], async (req, res) => {
  try {
    const { startDate, endDate, groupBy = 'day' } = req.query;
    
    const start = startDate ? new Date(startDate) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const end = endDate ? new Date(endDate) : new Date();
    
    // Set end date to end of day
    end.setHours(23, 59, 59, 999);

    const matchStage = {
      createdAt: { $gte: start, $lte: end },
      status: { $in: ['served', 'paid'] }
    };

    let groupStage;
    switch (groupBy) {
      case 'hour':
        groupStage = {
          _id: {
            year: { $year: '$createdAt' },
            month: { $month: '$createdAt' },
            day: { $dayOfMonth: '$createdAt' },
            hour: { $hour: '$createdAt' }
          }
        };
        break;
      case 'day':
        groupStage = {
          _id: {
            year: { $year: '$createdAt' },
            month: { $month: '$createdAt' },
            day: { $dayOfMonth: '$createdAt' }
          }
        };
        break;
      case 'month':
        groupStage = {
          _id: {
            year: { $year: '$createdAt' },
            month: { $month: '$createdAt' }
          }
        };
        break;
      default:
        groupStage = { _id: null };
    }

    const salesData = await Order.aggregate([
      { $match: matchStage },
      {
        $group: {
          ...groupStage,
          totalSales: { $sum: '$total' },
          totalOrders: { $sum: 1 },
          averageTicket: { $avg: '$total' },
          totalItems: { $sum: { $size: '$items' } }
        }
      },
      { $sort: { '_id': 1 } }
    ]);

    // Get payment method distribution
    const paymentMethods = await Order.aggregate([
      { $match: matchStage },
      {
        $group: {
          _id: '$paymentMethod',
          count: { $sum: 1 },
          total: { $sum: '$total' }
        }
      }
    ]);

    // Get order type distribution
    const orderTypes = await Order.aggregate([
      { $match: matchStage },
      {
        $group: {
          _id: '$type',
          count: { $sum: 1 },
          total: { $sum: '$total' }
        }
      }
    ]);

    res.json({
      success: true,
      data: {
        period: { start, end },
        salesData,
        paymentMethods,
        orderTypes,
        summary: {
          totalSales: salesData.reduce((sum, item) => sum + item.totalSales, 0),
          totalOrders: salesData.reduce((sum, item) => sum + item.totalOrders, 0),
          averageTicket: salesData.length > 0 
            ? salesData.reduce((sum, item) => sum + item.averageTicket, 0) / salesData.length 
            : 0
        }
      }
    });
  } catch (error) {
    console.error('Get sales report error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   GET /api/reports/products
// @desc    Get products report
// @access  Private (Admin/Manager only)
router.get('/products', [auth, authorize('admin', 'manager')], async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    
    const start = startDate ? new Date(startDate) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const end = endDate ? new Date(endDate) : new Date();
    end.setHours(23, 59, 59, 999);

    const matchStage = {
      createdAt: { $gte: start, $lte: end },
      status: { $in: ['served', 'paid'] }
    };

    // Top selling products
    const topProducts = await Order.aggregate([
      { $match: matchStage },
      { $unwind: '$items' },
      {
        $group: {
          _id: '$items.menuItem',
          totalQuantity: { $sum: '$items.quantity' },
          totalRevenue: { $sum: { $multiply: ['$items.quantity', '$items.price'] } },
          orderCount: { $sum: 1 }
        }
      },
      {
        $lookup: {
          from: 'menuitems',
          localField: '_id',
          foreignField: '_id',
          as: 'menuItem'
        }
      },
      { $unwind: '$menuItem' },
      {
        $project: {
          name: '$menuItem.name',
          category: '$menuItem.category',
          totalQuantity: 1,
          totalRevenue: 1,
          orderCount: 1,
          averagePrice: { $divide: ['$totalRevenue', '$totalQuantity'] }
        }
      },
      { $sort: { totalRevenue: -1 } },
      { $limit: 20 }
    ]);

    // Sales by category
    const categoryData = await Order.aggregate([
      { $match: matchStage },
      { $unwind: '$items' },
      {
        $lookup: {
          from: 'menuitems',
          localField: 'items.menuItem',
          foreignField: '_id',
          as: 'menuItem'
        }
      },
      { $unwind: '$menuItem' },
      {
        $group: {
          _id: '$menuItem.category',
          totalQuantity: { $sum: '$items.quantity' },
          totalRevenue: { $sum: { $multiply: ['$items.quantity', '$items.price'] } },
          itemCount: { $sum: 1 }
        }
      },
      { $sort: { totalRevenue: -1 } }
    ]);

    res.json({
      success: true,
      data: {
        period: { start, end },
        topProducts,
        categoryData
      }
    });
  } catch (error) {
    console.error('Get products report error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   GET /api/reports/dashboard
// @desc    Get dashboard statistics
// @access  Private
router.get('/dashboard', auth, async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    // Today's stats
    const todayStats = await Order.aggregate([
      {
        $match: {
          createdAt: { $gte: today, $lt: tomorrow },
          status: { $ne: 'cancelled' }
        }
      },
      {
        $group: {
          _id: null,
          totalSales: { $sum: '$total' },
          totalOrders: { $sum: 1 },
          paidOrders: {
            $sum: { $cond: [{ $eq: ['$status', 'paid'] }, 1, 0] }
          },
          pendingOrders: {
            $sum: { $cond: [{ $eq: ['$status', 'pending'] }, 1, 0] }
          },
          preparingOrders: {
            $sum: { $cond: [{ $eq: ['$status', 'preparing'] }, 1, 0] }
          },
          readyOrders: {
            $sum: { $cond: [{ $eq: ['$status', 'ready'] }, 1, 0] }
          }
        }
      }
    ]);

    // This week vs last week comparison
    const thisWeekStart = new Date(today);
    thisWeekStart.setDate(today.getDate() - today.getDay());
    
    const lastWeekStart = new Date(thisWeekStart);
    lastWeekStart.setDate(thisWeekStart.getDate() - 7);
    const lastWeekEnd = new Date(thisWeekStart);

    const [thisWeekStats, lastWeekStats] = await Promise.all([
      Order.aggregate([
        {
          $match: {
            createdAt: { $gte: thisWeekStart },
            status: { $in: ['served', 'paid'] }
          }
        },
        {
          $group: {
            _id: null,
            totalSales: { $sum: '$total' },
            totalOrders: { $sum: 1 }
          }
        }
      ]),
      Order.aggregate([
        {
          $match: {
            createdAt: { $gte: lastWeekStart, $lt: lastWeekEnd },
            status: { $in: ['served', 'paid'] }
          }
        },
        {
          $group: {
            _id: null,
            totalSales: { $sum: '$total' },
            totalOrders: { $sum: 1 }
          }
        }
      ])
    ]);

    // Calculate growth percentages
    const thisWeek = thisWeekStats[0] || { totalSales: 0, totalOrders: 0 };
    const lastWeek = lastWeekStats[0] || { totalSales: 0, totalOrders: 0 };
    
    const salesGrowth = lastWeek.totalSales > 0 
      ? ((thisWeek.totalSales - lastWeek.totalSales) / lastWeek.totalSales) * 100 
      : 0;
    
    const ordersGrowth = lastWeek.totalOrders > 0 
      ? ((thisWeek.totalOrders - lastWeek.totalOrders) / lastWeek.totalOrders) * 100 
      : 0;

    // Get table occupancy
    const Table = require('../models/Table');
    const tableStats = await Table.aggregate([
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 }
        }
      }
    ]);

    const tableOccupancy = tableStats.reduce((acc, stat) => {
      acc[stat._id] = stat.count;
      return acc;
    }, {});

    res.json({
      success: true,
      data: {
        today: todayStats[0] || {
          totalSales: 0,
          totalOrders: 0,
          paidOrders: 0,
          pendingOrders: 0,
          preparingOrders: 0,
          readyOrders: 0
        },
        growth: {
          sales: salesGrowth,
          orders: ordersGrowth
        },
        tables: {
          total: Object.values(tableOccupancy).reduce((sum, count) => sum + count, 0),
          occupied: tableOccupancy.occupied || 0,
          available: tableOccupancy.available || 0,
          reserved: tableOccupancy.reserved || 0,
          maintenance: tableOccupancy.maintenance || 0
        }
      }
    });
  } catch (error) {
    console.error('Get dashboard stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

module.exports = router;