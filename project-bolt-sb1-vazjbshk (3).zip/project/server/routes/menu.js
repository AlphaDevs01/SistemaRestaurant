const express = require('express');
const { body, validationResult } = require('express-validator');
const MenuItem = require('../models/MenuItem');
const { auth, authorize } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/menu
// @desc    Get all menu items
// @access  Public (for digital menu) / Private (for management)
router.get('/', async (req, res) => {
  try {
    const { category, available, search } = req.query;
    let query = {};

    // Filter by category
    if (category) {
      query.category = category;
    }

    // Filter by availability
    if (available !== undefined) {
      query.isAvailable = available === 'true';
    }

    // Search by name or description
    if (search) {
      query.$text = { $search: search };
    }

    const menuItems = await MenuItem.find(query).sort({ category: 1, name: 1 });

    res.json({
      success: true,
      data: menuItems
    });
  } catch (error) {
    console.error('Get menu items error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   GET /api/menu/categories
// @desc    Get all categories
// @access  Public
router.get('/categories', async (req, res) => {
  try {
    const categories = await MenuItem.distinct('category');
    
    res.json({
      success: true,
      data: categories
    });
  } catch (error) {
    console.error('Get categories error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   GET /api/menu/:id
// @desc    Get menu item by ID
// @access  Public
router.get('/:id', async (req, res) => {
  try {
    const menuItem = await MenuItem.findById(req.params.id);
    
    if (!menuItem) {
      return res.status(404).json({
        success: false,
        message: 'Item não encontrado'
      });
    }

    res.json({
      success: true,
      data: menuItem
    });
  } catch (error) {
    console.error('Get menu item error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   POST /api/menu
// @desc    Create new menu item
// @access  Private (Admin/Manager only)
router.post('/', [auth, authorize('admin', 'manager')], [
  body('name').trim().isLength({ min: 1 }).withMessage('Nome é obrigatório'),
  body('description').trim().isLength({ min: 1 }).withMessage('Descrição é obrigatória'),
  body('price').isFloat({ min: 0 }).withMessage('Preço deve ser um número positivo'),
  body('category').trim().isLength({ min: 1 }).withMessage('Categoria é obrigatória'),
  body('preparationTime').isInt({ min: 1 }).withMessage('Tempo de preparo deve ser um número positivo')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: errors.array()
      });
    }

    const menuItem = new MenuItem(req.body);
    await menuItem.save();

    res.status(201).json({
      success: true,
      message: 'Item criado com sucesso',
      data: menuItem
    });
  } catch (error) {
    console.error('Create menu item error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   PUT /api/menu/:id
// @desc    Update menu item
// @access  Private (Admin/Manager only)
router.put('/:id', [auth, authorize('admin', 'manager')], [
  body('name').optional().trim().isLength({ min: 1 }).withMessage('Nome não pode estar vazio'),
  body('description').optional().trim().isLength({ min: 1 }).withMessage('Descrição não pode estar vazia'),
  body('price').optional().isFloat({ min: 0 }).withMessage('Preço deve ser um número positivo'),
  body('category').optional().trim().isLength({ min: 1 }).withMessage('Categoria não pode estar vazia'),
  body('preparationTime').optional().isInt({ min: 1 }).withMessage('Tempo de preparo deve ser um número positivo')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: errors.array()
      });
    }

    const menuItem = await MenuItem.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!menuItem) {
      return res.status(404).json({
        success: false,
        message: 'Item não encontrado'
      });
    }

    res.json({
      success: true,
      message: 'Item atualizado com sucesso',
      data: menuItem
    });
  } catch (error) {
    console.error('Update menu item error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   PUT /api/menu/:id/availability
// @desc    Toggle menu item availability
// @access  Private (Admin/Manager only)
router.put('/:id/availability', [auth, authorize('admin', 'manager')], [
  body('isAvailable').isBoolean().withMessage('Disponibilidade deve ser verdadeiro ou falso')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: errors.array()
      });
    }

    const menuItem = await MenuItem.findByIdAndUpdate(
      req.params.id,
      { isAvailable: req.body.isAvailable },
      { new: true }
    );

    if (!menuItem) {
      return res.status(404).json({
        success: false,
        message: 'Item não encontrado'
      });
    }

    // Emit real-time update
    req.app.get('io').emit('menu-item-availability-changed', {
      itemId: menuItem._id,
      isAvailable: menuItem.isAvailable
    });

    res.json({
      success: true,
      message: `Item ${menuItem.isAvailable ? 'disponibilizado' : 'indisponibilizado'} com sucesso`,
      data: menuItem
    });
  } catch (error) {
    console.error('Update menu item availability error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   DELETE /api/menu/:id
// @desc    Delete menu item
// @access  Private (Admin only)
router.delete('/:id', [auth, authorize('admin')], async (req, res) => {
  try {
    const menuItem = await MenuItem.findById(req.params.id);
    
    if (!menuItem) {
      return res.status(404).json({
        success: false,
        message: 'Item não encontrado'
      });
    }

    await menuItem.deleteOne();

    res.json({
      success: true,
      message: 'Item excluído com sucesso'
    });
  } catch (error) {
    console.error('Delete menu item error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

module.exports = router;