const express = require('express');
const { body, validationResult } = require('express-validator');
const Customer = require('../models/Customer');
const { auth } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/customers
// @desc    Get all customers
// @access  Private
router.get('/', auth, async (req, res) => {
  try {
    const { search, active } = req.query;
    let query = {};

    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { phone: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } }
      ];
    }

    if (active !== undefined) {
      query.isActive = active === 'true';
    }

    const customers = await Customer.find(query)
      .populate('orderHistory')
      .sort({ name: 1 });

    res.json({
      success: true,
      data: customers
    });
  } catch (error) {
    console.error('Get customers error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   GET /api/customers/:id
// @desc    Get customer by ID
// @access  Private
router.get('/:id', auth, async (req, res) => {
  try {
    const customer = await Customer.findById(req.params.id)
      .populate('orderHistory');

    if (!customer) {
      return res.status(404).json({
        success: false,
        message: 'Cliente não encontrado'
      });
    }

    res.json({
      success: true,
      data: customer
    });
  } catch (error) {
    console.error('Get customer error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   POST /api/customers
// @desc    Create new customer
// @access  Private
router.post('/', auth, [
  body('name').trim().isLength({ min: 1 }).withMessage('Nome é obrigatório'),
  body('phone').matches(/^\(\d{2}\)\s\d{4,5}-\d{4}$/).withMessage('Telefone inválido'),
  body('email').optional().isEmail().withMessage('Email inválido'),
  body('cpf').optional().matches(/^\d{3}\.\d{3}\.\d{3}-\d{2}$/).withMessage('CPF inválido')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: errors.array()
      });
    }

    // Check if customer with same phone already exists
    const existingCustomer = await Customer.findOne({ phone: req.body.phone });
    if (existingCustomer) {
      return res.status(400).json({
        success: false,
        message: 'Cliente com este telefone já existe'
      });
    }

    const customer = new Customer(req.body);
    await customer.save();

    res.status(201).json({
      success: true,
      message: 'Cliente criado com sucesso',
      data: customer
    });
  } catch (error) {
    console.error('Create customer error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   PUT /api/customers/:id
// @desc    Update customer
// @access  Private
router.put('/:id', auth, [
  body('name').optional().trim().isLength({ min: 1 }).withMessage('Nome não pode estar vazio'),
  body('phone').optional().matches(/^\(\d{2}\)\s\d{4,5}-\d{4}$/).withMessage('Telefone inválido'),
  body('email').optional().isEmail().withMessage('Email inválido'),
  body('cpf').optional().matches(/^\d{3}\.\d{3}\.\d{3}-\d{2}$/).withMessage('CPF inválido')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: errors.array()
      });
    }

    const customer = await Customer.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!customer) {
      return res.status(404).json({
        success: false,
        message: 'Cliente não encontrado'
      });
    }

    res.json({
      success: true,
      message: 'Cliente atualizado com sucesso',
      data: customer
    });
  } catch (error) {
    console.error('Update customer error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   POST /api/customers/:id/addresses
// @desc    Add address to customer
// @access  Private
router.post('/:id/addresses', auth, [
  body('street').trim().isLength({ min: 1 }).withMessage('Rua é obrigatória'),
  body('number').trim().isLength({ min: 1 }).withMessage('Número é obrigatório'),
  body('neighborhood').trim().isLength({ min: 1 }).withMessage('Bairro é obrigatório'),
  body('city').trim().isLength({ min: 1 }).withMessage('Cidade é obrigatória'),
  body('state').trim().isLength({ min: 2, max: 2 }).withMessage('Estado deve ter 2 caracteres'),
  body('zipCode').matches(/^\d{5}-?\d{3}$/).withMessage('CEP inválido')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: errors.array()
      });
    }

    const customer = await Customer.findById(req.params.id);
    if (!customer) {
      return res.status(404).json({
        success: false,
        message: 'Cliente não encontrado'
      });
    }

    // If this is the first address or marked as default, make it default
    const isDefault = req.body.isDefault || customer.addresses.length === 0;
    
    // If setting as default, unset other default addresses
    if (isDefault) {
      customer.addresses.forEach(addr => addr.isDefault = false);
    }

    customer.addresses.push({ ...req.body, isDefault });
    await customer.save();

    res.status(201).json({
      success: true,
      message: 'Endereço adicionado com sucesso',
      data: customer
    });
  } catch (error) {
    console.error('Add customer address error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   PUT /api/customers/:id/addresses/:addressId
// @desc    Update customer address
// @access  Private
router.put('/:id/addresses/:addressId', auth, async (req, res) => {
  try {
    const customer = await Customer.findById(req.params.id);
    if (!customer) {
      return res.status(404).json({
        success: false,
        message: 'Cliente não encontrado'
      });
    }

    const address = customer.addresses.id(req.params.addressId);
    if (!address) {
      return res.status(404).json({
        success: false,
        message: 'Endereço não encontrado'
      });
    }

    // If setting as default, unset other default addresses
    if (req.body.isDefault) {
      customer.addresses.forEach(addr => addr.isDefault = false);
    }

    Object.assign(address, req.body);
    await customer.save();

    res.json({
      success: true,
      message: 'Endereço atualizado com sucesso',
      data: customer
    });
  } catch (error) {
    console.error('Update customer address error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   DELETE /api/customers/:id/addresses/:addressId
// @desc    Delete customer address
// @access  Private
router.delete('/:id/addresses/:addressId', auth, async (req, res) => {
  try {
    const customer = await Customer.findById(req.params.id);
    if (!customer) {
      return res.status(404).json({
        success: false,
        message: 'Cliente não encontrado'
      });
    }

    const address = customer.addresses.id(req.params.addressId);
    if (!address) {
      return res.status(404).json({
        success: false,
        message: 'Endereço não encontrado'
      });
    }

    address.deleteOne();
    await customer.save();

    res.json({
      success: true,
      message: 'Endereço excluído com sucesso',
      data: customer
    });
  } catch (error) {
    console.error('Delete customer address error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

module.exports = router;