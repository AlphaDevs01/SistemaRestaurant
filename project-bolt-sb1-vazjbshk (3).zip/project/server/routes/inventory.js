const express = require('express');
const { body, validationResult } = require('express-validator');
const InventoryItem = require('../models/InventoryItem');
const { auth, authorize } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/inventory
// @desc    Get all inventory items
// @access  Private
router.get('/', auth, async (req, res) => {
  try {
    const { category, lowStock } = req.query;
    let query = {};

    if (category) {
      query.category = category;
    }

    if (lowStock === 'true') {
      query.$expr = { $lte: ['$currentStock', '$minimumStock'] };
    }

    const items = await InventoryItem.find(query).sort({ name: 1 });

    res.json({
      success: true,
      data: items
    });
  } catch (error) {
    console.error('Get inventory error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   GET /api/inventory/categories
// @desc    Get all inventory categories
// @access  Private
router.get('/categories', auth, async (req, res) => {
  try {
    const categories = await InventoryItem.distinct('category');
    
    res.json({
      success: true,
      data: categories
    });
  } catch (error) {
    console.error('Get inventory categories error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   GET /api/inventory/low-stock
// @desc    Get items with low stock
// @access  Private
router.get('/low-stock', auth, async (req, res) => {
  try {
    const items = await InventoryItem.find({
      $expr: { $lte: ['$currentStock', '$minimumStock'] }
    }).sort({ currentStock: 1 });

    res.json({
      success: true,
      data: items
    });
  } catch (error) {
    console.error('Get low stock items error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   GET /api/inventory/:id
// @desc    Get inventory item by ID
// @access  Private
router.get('/:id', auth, async (req, res) => {
  try {
    const item = await InventoryItem.findById(req.params.id);
    
    if (!item) {
      return res.status(404).json({
        success: false,
        message: 'Item não encontrado'
      });
    }

    res.json({
      success: true,
      data: item
    });
  } catch (error) {
    console.error('Get inventory item error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   POST /api/inventory
// @desc    Create new inventory item
// @access  Private (Admin/Manager only)
router.post('/', [auth, authorize('admin', 'manager')], [
  body('name').trim().isLength({ min: 1 }).withMessage('Nome é obrigatório'),
  body('category').trim().isLength({ min: 1 }).withMessage('Categoria é obrigatória'),
  body('unit').trim().isLength({ min: 1 }).withMessage('Unidade é obrigatória'),
  body('currentStock').isFloat({ min: 0 }).withMessage('Estoque atual deve ser um número positivo'),
  body('minimumStock').isFloat({ min: 0 }).withMessage('Estoque mínimo deve ser um número positivo'),
  body('maximumStock').isFloat({ min: 1 }).withMessage('Estoque máximo deve ser maior que 0'),
  body('unitCost').isFloat({ min: 0 }).withMessage('Custo unitário deve ser um número positivo')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: errors.array()
      });
    }

    const item = new InventoryItem(req.body);
    await item.save();

    res.status(201).json({
      success: true,
      message: 'Item criado com sucesso',
      data: item
    });
  } catch (error) {
    console.error('Create inventory item error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   PUT /api/inventory/:id
// @desc    Update inventory item
// @access  Private (Admin/Manager only)
router.put('/:id', [auth, authorize('admin', 'manager')], [
  body('name').optional().trim().isLength({ min: 1 }).withMessage('Nome não pode estar vazio'),
  body('category').optional().trim().isLength({ min: 1 }).withMessage('Categoria não pode estar vazia'),
  body('unit').optional().trim().isLength({ min: 1 }).withMessage('Unidade não pode estar vazia'),
  body('currentStock').optional().isFloat({ min: 0 }).withMessage('Estoque atual deve ser um número positivo'),
  body('minimumStock').optional().isFloat({ min: 0 }).withMessage('Estoque mínimo deve ser um número positivo'),
  body('maximumStock').optional().isFloat({ min: 1 }).withMessage('Estoque máximo deve ser maior que 0'),
  body('unitCost').optional().isFloat({ min: 0 }).withMessage('Custo unitário deve ser um número positivo')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: errors.array()
      });
    }

    const item = await InventoryItem.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!item) {
      return res.status(404).json({
        success: false,
        message: 'Item não encontrado'
      });
    }

    res.json({
      success: true,
      message: 'Item atualizado com sucesso',
      data: item
    });
  } catch (error) {
    console.error('Update inventory item error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   PUT /api/inventory/:id/stock
// @desc    Update inventory item stock
// @access  Private (Admin/Manager only)
router.put('/:id/stock', [auth, authorize('admin', 'manager')], [
  body('quantity').isFloat().withMessage('Quantidade deve ser um número'),
  body('type').isIn(['add', 'subtract', 'set']).withMessage('Tipo deve ser add, subtract ou set'),
  body('reason').optional().trim().isLength({ min: 1 }).withMessage('Motivo não pode estar vazio')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: errors.array()
      });
    }

    const { quantity, type, reason } = req.body;
    const item = await InventoryItem.findById(req.params.id);

    if (!item) {
      return res.status(404).json({
        success: false,
        message: 'Item não encontrado'
      });
    }

    let newStock = item.currentStock;

    switch (type) {
      case 'add':
        newStock += quantity;
        break;
      case 'subtract':
        newStock -= quantity;
        break;
      case 'set':
        newStock = quantity;
        break;
    }

    if (newStock < 0) {
      return res.status(400).json({
        success: false,
        message: 'Estoque não pode ser negativo'
      });
    }

    item.currentStock = newStock;
    await item.save();

    // Log the stock movement (in a real app, you'd have a StockMovement model)
    console.log(`Stock movement: ${item.name} - ${type} ${quantity} - Reason: ${reason || 'N/A'}`);

    res.json({
      success: true,
      message: 'Estoque atualizado com sucesso',
      data: item
    });
  } catch (error) {
    console.error('Update inventory stock error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   DELETE /api/inventory/:id
// @desc    Delete inventory item
// @access  Private (Admin only)
router.delete('/:id', [auth, authorize('admin')], async (req, res) => {
  try {
    const item = await InventoryItem.findById(req.params.id);
    
    if (!item) {
      return res.status(404).json({
        success: false,
        message: 'Item não encontrado'
      });
    }

    await item.deleteOne();

    res.json({
      success: true,
      message: 'Item excluído com sucesso'
    });
  } catch (error) {
    console.error('Delete inventory item error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

module.exports = router;