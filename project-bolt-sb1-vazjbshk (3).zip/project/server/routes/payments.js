const express = require('express');
const { body, validationResult } = require('express-validator');
const Order = require('../models/Order');
const { auth } = require('../middleware/auth');

const router = express.Router();

// @route   POST /api/payments/process
// @desc    Process payment for an order
// @access  Private
router.post('/process', auth, [
  body('orderId').isMongoId().withMessage('ID do pedido inválido'),
  body('method').isIn(['cash', 'credit', 'debit', 'pix', 'voucher']).withMessage('Método de pagamento inválido'),
  body('amount').isFloat({ min: 0 }).withMessage('Valor deve ser um número positivo'),
  body('tip').optional().isFloat({ min: 0 }).withMessage('Gorjeta deve ser um número positivo'),
  body('discount').optional().isFloat({ min: 0 }).withMessage('Desconto deve ser um número positivo')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: errors.array()
      });
    }

    const { orderId, method, amount, tip = 0, discount = 0 } = req.body;

    const order = await Order.findById(orderId);
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Pedido não encontrado'
      });
    }

    if (order.paymentStatus === 'paid') {
      return res.status(400).json({
        success: false,
        message: 'Pedido já foi pago'
      });
    }

    // Update order with payment information
    order.paymentMethod = method;
    order.tip = tip;
    order.discount = discount;
    order.paymentStatus = 'paid';
    order.status = 'paid';

    // Recalculate total
    order.total = order.subtotal + order.tax + order.deliveryFee + tip - discount;

    if (amount < order.total) {
      return res.status(400).json({
        success: false,
        message: 'Valor pago é menor que o total do pedido'
      });
    }

    await order.save();

    // Simulate payment processing based on method
    let paymentResult = { success: true };
    
    switch (method) {
      case 'credit':
      case 'debit':
        // Simulate card processing
        paymentResult = await processCardPayment(amount, method);
        break;
      case 'pix':
        // Simulate PIX processing
        paymentResult = await processPixPayment(amount);
        break;
      case 'cash':
        // Cash payment is always successful
        paymentResult = { success: true, change: amount - order.total };
        break;
      case 'voucher':
        // Simulate voucher validation
        paymentResult = await processVoucherPayment(amount);
        break;
    }

    if (!paymentResult.success) {
      order.paymentStatus = 'failed';
      await order.save();
      
      return res.status(400).json({
        success: false,
        message: 'Falha no processamento do pagamento'
      });
    }

    // Update table status if dine-in order
    if (order.tableId) {
      const Table = require('../models/Table');
      await Table.findByIdAndUpdate(order.tableId, {
        status: 'available',
        currentOrder: null
      });
    }

    // Emit real-time update
    req.app.get('io').emit('payment-processed', {
      orderId: order._id,
      tableId: order.tableId,
      amount: order.total,
      method
    });

    res.json({
      success: true,
      message: 'Pagamento processado com sucesso',
      data: {
        order,
        payment: {
          method,
          amount: order.total,
          change: paymentResult.change || 0,
          transactionId: paymentResult.transactionId
        }
      }
    });
  } catch (error) {
    console.error('Process payment error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   POST /api/payments/split
// @desc    Split payment for an order
// @access  Private
router.post('/split', auth, [
  body('orderId').isMongoId().withMessage('ID do pedido inválido'),
  body('payments').isArray({ min: 1 }).withMessage('Pelo menos um pagamento é obrigatório'),
  body('payments.*.method').isIn(['cash', 'credit', 'debit', 'pix', 'voucher']).withMessage('Método de pagamento inválido'),
  body('payments.*.amount').isFloat({ min: 0 }).withMessage('Valor deve ser um número positivo')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: errors.array()
      });
    }

    const { orderId, payments } = req.body;

    const order = await Order.findById(orderId);
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Pedido não encontrado'
      });
    }

    if (order.paymentStatus === 'paid') {
      return res.status(400).json({
        success: false,
        message: 'Pedido já foi pago'
      });
    }

    // Validate total amount
    const totalPaid = payments.reduce((sum, payment) => sum + payment.amount, 0);
    if (totalPaid < order.total) {
      return res.status(400).json({
        success: false,
        message: 'Valor total pago é menor que o total do pedido'
      });
    }

    // Process each payment
    const paymentResults = [];
    for (const payment of payments) {
      let result;
      switch (payment.method) {
        case 'credit':
        case 'debit':
          result = await processCardPayment(payment.amount, payment.method);
          break;
        case 'pix':
          result = await processPixPayment(payment.amount);
          break;
        case 'cash':
          result = { success: true };
          break;
        case 'voucher':
          result = await processVoucherPayment(payment.amount);
          break;
      }
      
      paymentResults.push({ ...payment, ...result });
    }

    // Check if all payments were successful
    const allSuccessful = paymentResults.every(result => result.success);
    if (!allSuccessful) {
      return res.status(400).json({
        success: false,
        message: 'Falha em um ou mais pagamentos',
        data: paymentResults
      });
    }

    // Update order
    order.paymentStatus = 'paid';
    order.status = 'paid';
    await order.save();

    // Update table status if dine-in order
    if (order.tableId) {
      const Table = require('../models/Table');
      await Table.findByIdAndUpdate(order.tableId, {
        status: 'available',
        currentOrder: null
      });
    }

    // Emit real-time update
    req.app.get('io').emit('payment-processed', {
      orderId: order._id,
      tableId: order.tableId,
      amount: order.total,
      methods: payments.map(p => p.method)
    });

    res.json({
      success: true,
      message: 'Pagamentos processados com sucesso',
      data: {
        order,
        payments: paymentResults,
        change: totalPaid - order.total
      }
    });
  } catch (error) {
    console.error('Split payment error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   GET /api/payments/methods
// @desc    Get available payment methods
// @access  Private
router.get('/methods', auth, (req, res) => {
  const methods = [
    { id: 'cash', name: 'Dinheiro', icon: 'dollar-sign' },
    { id: 'credit', name: 'Cartão de Crédito', icon: 'credit-card' },
    { id: 'debit', name: 'Cartão de Débito', icon: 'credit-card' },
    { id: 'pix', name: 'PIX', icon: 'smartphone' },
    { id: 'voucher', name: 'Vale Refeição', icon: 'ticket' }
  ];

  res.json({
    success: true,
    data: methods
  });
});

// Simulate payment processing functions
async function processCardPayment(amount, method) {
  // Simulate card processing delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Simulate 95% success rate
  const success = Math.random() > 0.05;
  
  return {
    success,
    transactionId: success ? `TXN${Date.now()}` : null,
    message: success ? 'Pagamento aprovado' : 'Cartão recusado'
  };
}

async function processPixPayment(amount) {
  // Simulate PIX processing delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // PIX has higher success rate
  const success = Math.random() > 0.02;
  
  return {
    success,
    transactionId: success ? `PIX${Date.now()}` : null,
    message: success ? 'PIX processado com sucesso' : 'Falha no PIX'
  };
}

async function processVoucherPayment(amount) {
  // Simulate voucher validation
  await new Promise(resolve => setTimeout(resolve, 800));
  
  // Simulate voucher validation
  const success = Math.random() > 0.1;
  
  return {
    success,
    transactionId: success ? `VOU${Date.now()}` : null,
    message: success ? 'Vale aceito' : 'Vale inválido ou sem saldo'
  };
}

module.exports = router;