const express = require('express');
const { body, validationResult } = require('express-validator');
const Order = require('../models/Order');
const Customer = require('../models/Customer');
const { auth } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/delivery/orders
// @desc    Get delivery orders
// @access  Private
router.get('/orders', auth, async (req, res) => {
  try {
    const { status, date } = req.query;
    let query = { type: 'delivery' };

    if (status) {
      query.deliveryStatus = status;
    }

    if (date) {
      const startDate = new Date(date);
      const endDate = new Date(date);
      endDate.setDate(endDate.getDate() + 1);
      query.createdAt = { $gte: startDate, $lt: endDate };
    }

    const orders = await Order.find(query)
      .populate('customerId', 'name phone email')
      .populate('items.menuItem', 'name category')
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      data: orders
    });
  } catch (error) {
    console.error('Get delivery orders error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   POST /api/delivery/orders
// @desc    Create delivery order
// @access  Private
router.post('/orders', auth, [
  body('customerId').isMongoId().withMessage('ID do cliente inválido'),
  body('items').isArray({ min: 1 }).withMessage('Pelo menos um item é obrigatório'),
  body('deliveryAddress').isObject().withMessage('Endereço de entrega é obrigatório'),
  body('deliveryAddress.street').trim().isLength({ min: 1 }).withMessage('Rua é obrigatória'),
  body('deliveryAddress.number').trim().isLength({ min: 1 }).withMessage('Número é obrigatório'),
  body('deliveryAddress.neighborhood').trim().isLength({ min: 1 }).withMessage('Bairro é obrigatório'),
  body('deliveryAddress.city').trim().isLength({ min: 1 }).withMessage('Cidade é obrigatória'),
  body('deliveryAddress.zipCode').matches(/^\d{5}-?\d{3}$/).withMessage('CEP inválido')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: errors.array()
      });
    }

    const { customerId, items, deliveryAddress, notes } = req.body;

    // Validate customer
    const customer = await Customer.findById(customerId);
    if (!customer) {
      return res.status(400).json({
        success: false,
        message: 'Cliente não encontrado'
      });
    }

    // Validate menu items and calculate prices
    const MenuItem = require('../models/MenuItem');
    const orderItems = [];
    let subtotal = 0;

    for (const item of items) {
      const menuItem = await MenuItem.findById(item.menuItem);
      if (!menuItem) {
        return res.status(400).json({
          success: false,
          message: `Item do menu não encontrado: ${item.menuItem}`
        });
      }

      if (!menuItem.isAvailable) {
        return res.status(400).json({
          success: false,
          message: `Item não disponível: ${menuItem.name}`
        });
      }

      const orderItem = {
        menuItem: menuItem._id,
        quantity: item.quantity,
        price: menuItem.price,
        notes: item.notes || '',
        modifications: item.modifications || []
      };

      orderItems.push(orderItem);
      subtotal += menuItem.price * item.quantity;
    }

    // Calculate delivery fee based on distance (simplified)
    const deliveryFee = calculateDeliveryFee(deliveryAddress);
    
    // Estimate delivery time
    const deliveryTime = estimateDeliveryTime(deliveryAddress);

    // Create order
    const order = new Order({
      type: 'delivery',
      customerId,
      items: orderItems,
      subtotal,
      deliveryAddress,
      deliveryFee,
      deliveryTime,
      deliveryStatus: 'pending',
      notes,
      trackingCode: generateTrackingCode()
    });

    await order.save();

    // Populate the order for response
    await order.populate('customerId', 'name phone email');
    await order.populate('items.menuItem', 'name category preparationTime');

    // Emit real-time update
    req.app.get('io').emit('new-delivery-order', order);

    res.status(201).json({
      success: true,
      message: 'Pedido de delivery criado com sucesso',
      data: order
    });
  } catch (error) {
    console.error('Create delivery order error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   PUT /api/delivery/orders/:id/status
// @desc    Update delivery order status
// @access  Private
router.put('/orders/:id/status', auth, [
  body('deliveryStatus').isIn(['pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered', 'cancelled']).withMessage('Status inválido')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: errors.array()
      });
    }

    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Pedido não encontrado'
      });
    }

    if (order.type !== 'delivery') {
      return res.status(400).json({
        success: false,
        message: 'Este não é um pedido de delivery'
      });
    }

    const { deliveryStatus } = req.body;
    order.deliveryStatus = deliveryStatus;

    // Update main order status based on delivery status
    switch (deliveryStatus) {
      case 'confirmed':
        order.status = 'pending';
        break;
      case 'preparing':
        order.status = 'preparing';
        break;
      case 'out_for_delivery':
        order.status = 'ready';
        break;
      case 'delivered':
        order.status = 'served';
        break;
      case 'cancelled':
        order.status = 'cancelled';
        break;
    }

    await order.save();

    // Emit real-time update
    req.app.get('io').emit('delivery-status-updated', {
      orderId: order._id,
      deliveryStatus,
      trackingCode: order.trackingCode
    });

    res.json({
      success: true,
      message: 'Status do delivery atualizado com sucesso',
      data: order
    });
  } catch (error) {
    console.error('Update delivery status error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   GET /api/delivery/track/:trackingCode
// @desc    Track delivery order
// @access  Public
router.get('/track/:trackingCode', async (req, res) => {
  try {
    const order = await Order.findOne({ 
      trackingCode: req.params.trackingCode,
      type: 'delivery'
    })
      .populate('items.menuItem', 'name')
      .select('orderNumber deliveryStatus deliveryTime estimatedTime createdAt items total');

    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Pedido não encontrado'
      });
    }

    // Calculate estimated delivery time
    const estimatedDelivery = new Date(order.createdAt);
    estimatedDelivery.setMinutes(estimatedDelivery.getMinutes() + order.deliveryTime);

    res.json({
      success: true,
      data: {
        orderNumber: order.orderNumber,
        status: order.deliveryStatus,
        estimatedDelivery,
        items: order.items.map(item => ({
          name: item.menuItem.name,
          quantity: item.quantity
        })),
        total: order.total
      }
    });
  } catch (error) {
    console.error('Track delivery error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   GET /api/delivery/stats
// @desc    Get delivery statistics
// @access  Private
router.get('/stats', auth, async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const stats = await Order.aggregate([
      {
        $match: {
          
          type: 'delivery',
          createdAt: { $gte: today }
        }
      },
      {
        $group: {
          _id: null,
          totalOrders: { $sum: 1 },
          totalRevenue: { $sum: '$total' },
          pendingOrders: {
            $sum: { $cond: [{ $eq: ['$deliveryStatus', 'pending'] }, 1, 0] }
          },
          confirmedOrders: {
            $sum: { $cond: [{ $eq: ['$deliveryStatus', 'confirmed'] }, 1, 0] }
          },
          preparingOrders: {
            $sum: { $cond: [{ $eq: ['$deliveryStatus', 'preparing'] }, 1, 0] }
          },
          outForDeliveryOrders: {
            $sum: { $cond: [{ $eq: ['$deliveryStatus', 'out_for_delivery'] }, 1, 0] }
          },
          deliveredOrders: {
            $sum: { $cond: [{ $eq: ['$deliveryStatus', 'delivered'] }, 1, 0] }
          },
          cancelledOrders: {
            $sum: { $cond: [{ $eq: ['$deliveryStatus', 'cancelled'] }, 1, 0] }
          },
          averageDeliveryTime: { $avg: '$deliveryTime' }
        }
      }
    ]);

    const result = stats[0] || {
      totalOrders: 0,
      totalRevenue: 0,
      pendingOrders: 0,
      confirmedOrders: 0,
      preparingOrders: 0,
      outForDeliveryOrders: 0,
      deliveredOrders: 0,
      cancelledOrders: 0,
      averageDeliveryTime: 0
    };

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    console.error('Get delivery stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// Helper functions
function calculateDeliveryFee(address) {
  // Simplified delivery fee calculation
  // In a real app, this would use a mapping service to calculate distance
  const baseDeliveryFee = 5.00;
  
  // Add extra fee for certain neighborhoods (example)
  const expensiveNeighborhoods = ['Centro', 'Jardins', 'Vila Madalena'];
  if (expensiveNeighborhoods.includes(address.neighborhood)) {
    return baseDeliveryFee + 2.00;
  }
  
  return baseDeliveryFee;
}

function estimateDeliveryTime(address) {
  // Simplified delivery time estimation (in minutes)
  // In a real app, this would use traffic data and distance calculation
  const baseTime = 30;
  
  // Add extra time for distant neighborhoods
  const distantNeighborhoods = ['Zona Sul', 'Zona Norte'];
  if (distantNeighborhoods.includes(address.neighborhood)) {
    return baseTime + 15;
  }
  
  return baseTime;
}

function generateTrackingCode() {
  const timestamp = Date.now().toString();
  const random = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `TRK${timestamp.slice(-6)}${random}`;
}

module.exports = router;