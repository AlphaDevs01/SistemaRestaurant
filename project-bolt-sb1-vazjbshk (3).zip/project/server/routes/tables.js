const express = require('express');
const { body, validationResult } = require('express-validator');
const Table = require('../models/Table');
const { auth, authorize } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/tables
// @desc    Get all tables
// @access  Private
router.get('/', auth, async (req, res) => {
  try {
    const tables = await Table.find().populate('currentOrder').sort({ number: 1 });
    
    res.json({
      success: true,
      data: tables
    });
  } catch (error) {
    console.error('Get tables error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   GET /api/tables/:id
// @desc    Get table by ID
// @access  Private
router.get('/:id', auth, async (req, res) => {
  try {
    const table = await Table.findById(req.params.id).populate('currentOrder');
    
    if (!table) {
      return res.status(404).json({
        success: false,
        message: 'Mesa não encontrada'
      });
    }

    res.json({
      success: true,
      data: table
    });
  } catch (error) {
    console.error('Get table error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   POST /api/tables
// @desc    Create new table
// @access  Private (Admin/Manager only)
router.post('/', [auth, authorize('admin', 'manager')], [
  body('number').isInt({ min: 1 }).withMessage('Número da mesa deve ser um inteiro positivo'),
  body('capacity').isInt({ min: 1, max: 20 }).withMessage('Capacidade deve ser entre 1 e 20'),
  body('section').trim().isLength({ min: 1 }).withMessage('Seção é obrigatória')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: errors.array()
      });
    }

    const { number, capacity, section, coordinates, notes } = req.body;

    // Check if table number already exists
    const existingTable = await Table.findOne({ number });
    if (existingTable) {
      return res.status(400).json({
        success: false,
        message: 'Número da mesa já existe'
      });
    }

    const table = new Table({
      number,
      capacity,
      section,
      coordinates,
      notes
    });

    await table.save();

    res.status(201).json({
      success: true,
      message: 'Mesa criada com sucesso',
      data: table
    });
  } catch (error) {
    console.error('Create table error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   PUT /api/tables/:id
// @desc    Update table
// @access  Private (Admin/Manager only)
router.put('/:id', [auth, authorize('admin', 'manager')], [
  body('number').optional().isInt({ min: 1 }).withMessage('Número da mesa deve ser um inteiro positivo'),
  body('capacity').optional().isInt({ min: 1, max: 20 }).withMessage('Capacidade deve ser entre 1 e 20'),
  body('section').optional().trim().isLength({ min: 1 }).withMessage('Seção não pode estar vazia'),
  body('status').optional().isIn(['available', 'occupied', 'reserved', 'maintenance']).withMessage('Status inválido')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: errors.array()
      });
    }

    const table = await Table.findById(req.params.id);
    if (!table) {
      return res.status(404).json({
        success: false,
        message: 'Mesa não encontrada'
      });
    }

    const { number, capacity, section, status, coordinates, notes } = req.body;

    // Check if new number already exists (if changing number)
    if (number && number !== table.number) {
      const existingTable = await Table.findOne({ number });
      if (existingTable) {
        return res.status(400).json({
          success: false,
          message: 'Número da mesa já existe'
        });
      }
    }

    // Update fields
    if (number) table.number = number;
    if (capacity) table.capacity = capacity;
    if (section) table.section = section;
    if (status) table.status = status;
    if (coordinates) table.coordinates = coordinates;
    if (notes !== undefined) table.notes = notes;

    await table.save();

    // Emit real-time update
    req.app.get('io').emit('table-updated', table);

    res.json({
      success: true,
      message: 'Mesa atualizada com sucesso',
      data: table
    });
  } catch (error) {
    console.error('Update table error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   PUT /api/tables/:id/status
// @desc    Update table status
// @access  Private
router.put('/:id/status', auth, [
  body('status').isIn(['available', 'occupied', 'reserved', 'maintenance']).withMessage('Status inválido')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: errors.array()
      });
    }

    const table = await Table.findById(req.params.id);
    if (!table) {
      return res.status(404).json({
        success: false,
        message: 'Mesa não encontrada'
      });
    }

    const { status } = req.body;
    table.status = status;

    // Clear current order if table becomes available
    if (status === 'available') {
      table.currentOrder = null;
    }

    await table.save();

    // Emit real-time update
    req.app.get('io').emit('table-status-updated', { tableId: table._id, status });

    res.json({
      success: true,
      message: 'Status da mesa atualizado com sucesso',
      data: table
    });
  } catch (error) {
    console.error('Update table status error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// @route   DELETE /api/tables/:id
// @desc    Delete table
// @access  Private (Admin only)
router.delete('/:id', [auth, authorize('admin')], async (req, res) => {
  try {
    const table = await Table.findById(req.params.id);
    if (!table) {
      return res.status(404).json({
        success: false,
        message: 'Mesa não encontrada'
      });
    }

    // Check if table is currently occupied
    if (table.status === 'occupied') {
      return res.status(400).json({
        success: false,
        message: 'Não é possível excluir mesa ocupada'
      });
    }

    await table.deleteOne();

    res.json({
      success: true,
      message: 'Mesa excluída com sucesso'
    });
  } catch (error) {
    console.error('Delete table error:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

module.exports = router;